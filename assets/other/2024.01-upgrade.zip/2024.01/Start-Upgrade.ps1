[CmdletBinding()]
param(
    [string]$ResourceGroup,
    [string]$Subscription,
    [string]$ValuesFileOverridePath,
    [switch]$SkipBackup
)

# Bootstrap
$chartVersion = '2.0.0'
$repoName = 'cluedin'
if (!(Get-Module -Name powershell-yaml)) { throw "Please install powershell-yaml module" }
$dataUpgradeCrd = 'dataupgrade-crd.yaml'
$upgradeCustomValues = 'platform-custom-values.yaml'
$upgradeStage1 = 'platform-upgrade-v2-stage1.yaml'
$upgradeStage2 = 'platform-upgrade-v2-stage2.yaml'

# Start and Validation
if ($ValuesFileOverridePath) {
    if (!(Test-Path -Path $ValuesFileOverridePath -PathType 'Leaf')) {
        throw "Issue with path '$ValuesFileOverridePath'. It must be full path to the YAML file"
    }
}

$customerName = Read-Host "Please enter customer name"
$customerEnvironment = Read-Host "Please enter customer environment"

$params = @(
    '--resource-group', $ResourceGroup
    '--subscription', $Subscription
    '--query', '[].{name: name, nodeResourceGroup: nodeResourceGroup}'
)
$aks = az aks list @params | ConvertFrom-Json
if (!$aks) { throw "Issue obtaining AKS cluster" }

$tempKubeConfig = (New-TemporaryFile).FullName

$contextName = ('{0}-{1}' -f $customerName, $customerEnvironment)
$params = @(
    '--resource-group', $ResourceGroup
    '--name', $aks.name
    '--file', $tempKubeConfig
    '--subscription', $Subscription
    '--context', $contextName
)
az aks get-credentials @params

Write-Host "Setting Temporary KubeConfig"
${env:KUBECONFIG} = $tempKubeConfig
if (! ((kubectl config current-context) -eq $contextName) ) { throw "Issue validating context" }

Write-Host "Validating Upgrade files"
$hothUpgradeFilesLocation = $PSScriptRoot # ie. /mnt/c/.sandbox/ama-hothupgrade
Write-Host "Using '$hothUpgradeFilesLocation' as upgrade location"

@(
    $dataUpgradeCrd
    $upgradeCustomValues
    $upgradeStage1
    $upgradeStage2
).ForEach({ if (!(Test-Path -Path (Join-Path -Path $hothUpgradeFilesLocation -ChildPath $_))) { throw "Cannot find '$_'" } })

Write-Host "Checking version exists"
$chartExists = helm search repo $repoName/cluedin-platform --devel --version $chartVersion --output json | ConvertFrom-Json
if (!$chartExists) { throw "Chart could not be found. Please investigate" }

# Ready for upgrade
if (!$SkipBackup) {
    Write-Host "Taking PVC snapshots"
    $pvcs = kubectl get pvc -n cluedin -o jsonpath='{range .items[*]}{.spec.volumeName}{"\n"}{end}'
    $azurePvcs = az disk list --resource-group $aks.nodeResourceGroup --query '[].{name: name, id: id}' --subscription $Subscription | ConvertFrom-Json
    if (!$?) { throw "Error with obtaining PVCs" }

    Foreach ($pvc in $pvcs) {
        if ($pvc -in $azurePvcs.name) {
            "Taking snapshot of $pvc"
            $source = $azurePvcs | Where-Object {$_.name -eq $pvc}
            $snapshotName = '{0}_backup' -f $pvc
            $params = @(
                '--resource-group', $aks.nodeResourceGroup
                '--name', $snapshotName
                '--source', $source.id
                '--subscription', $Subscription
                '--output', 'none'
            )
            az snapshot create @params
            if (!$?) { throw "error taking snapshot of '$pvc'" }
        }
    }
    Write-Host "PVC Snapshots now complete"
}

Write-Host "Getting current helm values"
New-Item -Path $hothUpgradeFilesLocation -Name $contextName -ItemType 'Directory' -Force | Out-Null
$customerFolderPath = Join-Path -Path $hothUpgradeFilesLocation -ChildPath $contextName
$customerValuesFile = Join-Path -Path $customerFolderPath -ChildPath ('{0}_values.yaml' -f $contextName)

if ($ValuesFileOverridePath) {
    Copy-Item -Path $ValuesFileOverridePath -Destination $customerValuesFile
}
else {
    $currentYaml = helm get values cluedin-platform --kubeconfig ${env:KUBECONFIG} -n cluedin --output yaml
    $currentYaml | Out-File -FilePath $customerValuesFile

    $destination = Join-Path -Path $customerFolderPath -ChildPath 'original_values.yaml'
    if (!(Test-Path -Path $destination -PathType Leaf)) {
        Copy-Item -Path $customerValuesFile -Destination $destination
    }
    else { Write-Host "Original Values exists, skipping." }
}

Write-Host "Checking values files for common culprits"
$devACRName = 'cluedindev.azurecr.io'
$devACRFound = $currentyaml | Select-String -Pattern $devAcrName
if ($devACRFound) { Write-Warning "ACR '$devACRName' found in file"; $adviseUser = $true }

$devNugetFeed = 'https://pkgs.dev.azure.com/CluedIn-io/_packaging/develop/'
$devNugetFeedFound = $currentyaml | Select-String -Pattern $devNugetFeed
if ($devNugetFeedFound) { Write-Warning "NuGet feed '$devNugetFeed' found in file"; $adviseUser = $true }

if ($adviseUser) {
    Write-Host "Before proceeding, please ensure any warnings are investigated as it may prevent a successful upgrade"
    Write-Host "You can update '$customerValuesFile' now and when you proceed, it'll grab any applied changes."
}

# Last chance to back out
while ($proceed -notmatch 'y') {
    $proceed = Read-Host "Starting Upgrade for '$contextName'. Proceed? [Y/n]"
    switch ($proceed) {
        'Y' {continue}
        'n' {throw "Killing upgrade"}
    }
}
$proceed = $null

# Environment YAML
$environmentYaml = Get-Content -Path $customerValuesFile -Raw | ConvertFrom-Yaml
if (!$?) { throw "Failed to convert environment yaml to an object" }

Write-Host "Starting upgrade"
Write-Host "Backing up neo4j password"
$neo4jPassword = kubectl get secret/cluedin-rabbitmq -n cluedin -o jsonpath='{.data.rabbitmq-password}' | base64 --decode
if (!$neo4jPassword) { throw "Issue obtaining neo4j password" }

$customValuesPath = Join-Path -Path $hothUpgradeFilesLocation -ChildPath $upgradeCustomValues
$customYaml = Get-Content -Path $customValuesPath -Raw | ConvertFrom-Yaml -Ordered

$upgradeCustomValuesFilePath = Join-Path -Path (Get-Item -Path $customerValuesFile).Directory.FullName -ChildPath $upgradeCustomValues

$customYaml.infrastructure.neo4j.neo4j.password = $neo4jPassword

Write-Host "Updating integration versions"
$currentPackages = $environmentYaml.application.cluedin.components.packages
$customYamlPackages = $customYaml.application.cluedin.components.packages

$customYaml.application.cluedin.components.packages = $currentPackages
$customYaml.application.cluedin.components.packages | ForEach-Object {
    $currentName = $_.name
    $newVersion = ($customYamlPackages | Where-Object {$_.name -match $currentName}).Version
    if ($newVersion) { $_.version = $newVersion }
}

$customYaml | ConvertTo-Yaml -OutFile $upgradeCustomValuesFilePath

Write-Host "Deploying Data upgrade CRD"
kubectl apply -f (Join-Path -Path $hothUpgradeFilesLocation -ChildPath $dataUpgradeCrd) -n 'cluedin'
if (!$?) { throw "Issue with deploying CRD. Please manually investigate" }

Write-Host "Performing Upgrade Stage 1"
Write-Host "Scaling down Instances"
$params = @(
    '--version', $chartVersion
    '--values', $customerValuesFile
    '--values', $upgradeCustomValuesFilePath
    '--values', (Join-Path -Path $hothUpgradeFilesLocation -ChildPath $upgradeStage1)
    '--wait'
)
helm upgrade cluedin-platform -n cluedin $repoName/cluedin-platform @params
if (!$?) { throw "Issue with Upgrade Stage 1" }

Write-Host "Waiting until all pods are killed"
$i = 0; $iMax = 5
$podsToDie = @(
    'crawling', 'grafana', 'cert-manager', 'controller'
    'datasource', 'elasticsearch', 'gql', 'haproxy'
    'libpostal', 'neo4j', 'openrefine', 'operator'
    'prepare', 'prometheus', 'rabbitmq', 'redis', 'server'
)
while ($true) {
    $podExists = $false
    if ($i -gt $iMax) { throw "Something went wrong waiting for pods to be terminated" }

    Write-Host "Checking status ($i/$iMax)"
    $currentPods = kubectl get pods -n cluedin -o json | ConvertFrom-Json
    $podsToDie.ForEach({
        if ($currentPods.items.metadata.name -match $_) { "Waiting on '$_'"; $podExists = $true}
    })

    if ($podExists) { $i++; Start-Sleep 30 }
    else { break }
}

Write-Host "Performing Upgrade Stage 2"
$params = @(
    '--version', $chartVersion
    '--values', $customerValuesFile
    '--values', $upgradeCustomValuesFilePath
    '--values', (Join-Path -Path $hothUpgradeFilesLocation -ChildPath $upgradeStage2)
)
helm upgrade cluedin-platform -n cluedin $repoName/cluedin-platform @params
if (!$?) { throw "Issue with Upgrade Stage 2" }

Write-Host "Waiting for application upgrades to complete"

kubectl wait --for=condition=complete job/init-neo4j-job -n 'cluedin' --timeout '20m'
if (!$?) { throw "Issue waiting on neo4j job to complete" }

kubectl wait --for=condition=complete job/init-sqlserver-job -n 'cluedin' --timeout '20m'
if (!$?) { throw "Issue waiting on sql job to complete" }

Write-Host "Performing Final Upgrade steps"
$params = @(
    '--version', $chartVersion
    '--values', $customerValuesFile
    '--values', $upgradeCustomValuesFilePath
    '--set', 'application.system.runDatabaseJobsOnUpgrade=true'
    '--set', 'application.system.runNugetFullRestore=true'
    '--set', 'infrastructure.cert-manager.cainjector.resources.limits.memory=128Mi'
    '--wait'
    '--timeout', '10m0s'
)
helm upgrade cluedin-platform -n cluedin $repoName/cluedin-platform @params
if (!$?) { Write-Warning "Issue with final upgrade stage. Please manually investigate." }

Write-Host "Exporting customers updated helm values"
$newYaml = helm get values cluedin-platform --kubeconfig ${env:KUBECONFIG} -n cluedin --output yaml
$newCustomerValuesFile = (Join-Path -Path $customerFolderPath -ChildPath ('{0}_values-new.yaml' -f $contextName))
$newYaml | Out-File -FilePath $newCustomerValuesFile

Write-Host "Deployment complete. Please validate the server is healthy before closing off."
Write-Host "It may take an additional 5-10 minutes before everything is green.`n"
if (!$SkipBackup) {
    Write-Host "There are snapshots of the PVC in Azure. Please ensure these eventually get removed."
}