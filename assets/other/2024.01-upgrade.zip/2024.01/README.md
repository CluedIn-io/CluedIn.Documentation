# Intro
This package support `2023.07` to `2024.01`

ref: https://runbook.cluedin.com/runbooks/upgrades/2024.01-beta/

# Prerequisites
- powershell-yaml installed
- WSL/Linux OS that has base64 app installed

# Documentation
1. Ensure the script folder contains the following files:
    - `dataupgrade-crd.yaml`
    - `platform-custom-values.yaml`
    - `platform-upgrade-v2-stage1.yaml`
    - `platform-upgrade-v2-stage2.yaml`
1. In pwsh, run Start-Upgrade.ps1 and pass in ResourceGroup and Subscription as parameters
1. During the run, it will ask for a customer name and environment. This is simply used to make friendly names of the output. It does not impact the run at all.

The script will take a snapshot of all PVCs that exist before upgrading commences.
It'll update the neo4j password during runtime and override the cert-manager webhook memory limit
It keeps a backup of the current values, and will export a new values at the end.